using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;
using System.Security.Cryptography;

public class AES
{
    public static byte[] AESEncrypt256(String Input, String key)
    {
        RijndaelManaged aes = new RijndaelManaged();
        aes.KeySize = 256;
        aes.BlockSize = 256;
        aes.Mode = CipherMode.CBC;
        aes.Padding = PaddingMode.None;
		int keyByteSize = aes.KeySize/8;
		byte[] keyBytes = new byte[keyByteSize];
		Encoding.UTF8.GetBytes(key, 0, keyByteSize, keyBytes, 0);
        aes.Key = keyBytes;
        aes.IV = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

        var encrypt = aes.CreateEncryptor(aes.Key, aes.IV);
        byte[] xBuff = null;
        using (var ms = new MemoryStream())
        {
            using (var cs = new CryptoStream(ms, encrypt, CryptoStreamMode.Write))
            {
                byte[] xXml = Encoding.UTF8.GetBytes(Input);
                cs.Write(xXml, 0, xXml.Length);
            }

            xBuff = ms.ToArray();
        }

        //String Output = Convert.ToBase64String(xBuff);
        return xBuff;
    }


    public static String AESDecrypt256(String Input, String key)
    {
        RijndaelManaged aes = new RijndaelManaged();
        aes.KeySize = 256;
        aes.BlockSize = 256;
        aes.Mode = CipherMode.CBC;
        aes.Padding = PaddingMode.None;
        aes.Key = Encoding.UTF8.GetBytes(key);
        aes.IV = new byte[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

        var decrypt = aes.CreateDecryptor();
        byte[] xBuff = null;
        using (var ms = new MemoryStream())
        {
            using (var cs = new CryptoStream(ms, decrypt, CryptoStreamMode.Write))
            {
                byte[] xXml = Convert.FromBase64String(Input);
                cs.Write(xXml, 0, xXml.Length);
            }

            xBuff = ms.ToArray();
        }

        String Output = Encoding.UTF8.GetString(xBuff);
        return Output;
    }


    public static String AESEncrypt128(String Input, String key)
    {
        
        RijndaelManaged RijndaelCipher = new RijndaelManaged();

        byte[] PlainText = System.Text.Encoding.Unicode.GetBytes(Input);
        byte[] Salt = Encoding.ASCII.GetBytes(key.Length.ToString());

        PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(key, Salt);
        ICryptoTransform Encryptor = RijndaelCipher.CreateEncryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16));

        MemoryStream memoryStream = new MemoryStream();
        CryptoStream cryptoStream = new CryptoStream(memoryStream, Encryptor, CryptoStreamMode.Write);

        cryptoStream.Write(PlainText, 0, PlainText.Length);
        cryptoStream.FlushFinalBlock();
        
        byte[] CipherBytes = memoryStream.ToArray();

        memoryStream.Close();
        cryptoStream.Close();

        string EncryptedData = Convert.ToBase64String(CipherBytes);

        return EncryptedData;
    }

    public static String AESDecrypt128(String Input, String key)
    {
        RijndaelManaged RijndaelCipher = new RijndaelManaged();

        byte[] EncryptedData = Convert.FromBase64String(Input);
        byte[] Salt = Encoding.ASCII.GetBytes(key.Length.ToString());

        PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(key, Salt);
        ICryptoTransform Decryptor = RijndaelCipher.CreateDecryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16));
        MemoryStream memoryStream = new MemoryStream(EncryptedData);
        CryptoStream cryptoStream = new CryptoStream(memoryStream, Decryptor, CryptoStreamMode.Read);

        byte[] PlainText = new byte[EncryptedData.Length];

        int DecryptedCount = cryptoStream.Read(PlainText, 0, PlainText.Length);

        memoryStream.Close();
        cryptoStream.Close();

        string DecryptedData = Encoding.Unicode.GetString(PlainText, 0, DecryptedCount);

        return DecryptedData;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// 
    public static string DecryptRJ256(string prm_key, string prm_iv, string prm_text_to_decrypt) {
        
        var sEncryptedString = prm_text_to_decrypt;
        
        var myRijndael = new RijndaelManaged() {
            Padding = PaddingMode.Zeros,
            Mode = CipherMode.CBC,
            KeySize = 256,
            BlockSize = 256
        };
        
        var key = Encoding.ASCII.GetBytes(prm_key);
        var IV = Encoding.ASCII.GetBytes(prm_iv);
        
        var decryptor = myRijndael.CreateDecryptor(key, IV);
        
        var sEncrypted = Convert.FromBase64String(sEncryptedString);
        
        var fromEncrypt = new byte[sEncrypted.Length];
        
        var msDecrypt = new MemoryStream(sEncrypted);
        var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read);
        
        csDecrypt.Read(fromEncrypt, 0, fromEncrypt.Length);
        
        return (Encoding.Default.GetString(fromEncrypt));
    }
    
    public static string EncryptRJ256(string prm_key, string prm_iv, string prm_text_to_encrypt) {
        
        var sToEncrypt = prm_text_to_encrypt;
        
        var myRijndael = new RijndaelManaged() {
            Padding = PaddingMode.Zeros,
            Mode = CipherMode.CBC,
            KeySize = 256,
            BlockSize = 256
        };
        
        var key = Encoding.ASCII.GetBytes(prm_key);
        var IV = Encoding.ASCII.GetBytes(prm_iv);
        
        var encryptor = myRijndael.CreateEncryptor(key, IV);
        
        var msEncrypt = new MemoryStream();
        var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write);
        
        var toEncrypt = Encoding.ASCII.GetBytes(sToEncrypt);
        
        csEncrypt.Write(toEncrypt, 0, toEncrypt.Length);
        csEncrypt.FlushFinalBlock();
        
        var encrypted = msEncrypt.ToArray();
        
        return (Convert.ToBase64String(encrypted));
    }

}