﻿using UnityEngine;
using System.Collections;
using System.Text;

public class DebugInfoHUD : MonoBehaviour
{
	public GameObject m_waterReflection;
    string buildInfo;
	public TimeScaleManager m_TSM;
	public GameObject m_bg, m_uiRoot;
	
	void Start()
	{
		buildInfo = (Resources.Load( "buildinfo") as TextAsset).text;
		if( guiText != null)
			guiText.text = buildInfo;
	}
	
	void Update()
	{

	}
	
	void OnGUI()
	{

		int gapSize = 10;
		GUILayoutOption heightOption = GUILayout.Height( 50);

		GUILayout.BeginArea( new Rect( 0, 100, 100, 400));

		GUILayout.Space( gapSize);

		if( GUILayout.Button( "Texture", heightOption))
		{
			Object[] sortedAll = FindObjectsOfTypeIncludingAssets(typeof(Texture2D));

			System.Array.Sort( sortedAll, delegate(Object a, Object b){
				if (a == b) return 0;
				//return (Profiler.GetRuntimeMemorySize(a) <= Profiler.GetRuntimeMemorySize(b)) ? -1 : 1;
				return a.name.CompareTo( b.name);
			});
			
			StringBuilder sb = new StringBuilder("");
			int memTexture = 0;
			for(int i = sortedAll.Length - 1; i>=0; --i){
				if(!sortedAll[i].name.StartsWith("d_")){
					memTexture += Profiler.GetRuntimeMemorySize(sortedAll[i]);
					sb.Append("Size#");
					sb.Append(sortedAll.Length - i);
					sb.Append(" / ");
					sb.Append(sortedAll[i].name);
					sb.Append(" / ");
					sb.Append((sortedAll[i] as Texture2D).format.ToString());
					sb.Append(" / Instance ID / ");
					sb.Append(sortedAll[i].GetInstanceID());
					sb.Append(" / Mem / ");
					sb.Append(Profiler.GetRuntimeMemorySize(sortedAll[i]).ToString());
					sb.Append("B / Total / ");
					sb.Append(memTexture/1024);
					sb.Append("KB ");
					sb.Append("\n");
					
				}
			}
			Debug.Log("Texture2D Inspect: "+sb.ToString());
			Util.writeStringToFile(sb.ToString(), "TextureLog_" + SystemInfo.deviceModel);
		}
		
		GUILayout.Space( gapSize);
		if( GUILayout.Button( "Toggle BG", heightOption))
		{
			if( m_bg.activeSelf)
				m_bg.SetActive( false);
			else
				m_bg.SetActive( true);
		}

		GUILayout.Space( gapSize);
		if( GUILayout.Button( "Toggle NGUI", heightOption))
		{
			if( m_uiRoot.activeSelf)
				m_uiRoot.SetActive( false);
			else
				m_uiRoot.SetActive( true);
		}
		/*
		GUILayout.Space( gapSize);
		if( GUILayout.Button( "Toggle Water", heightOption))
		{
			if( m_waterReflection.activeSelf)
				m_waterReflection.SetActive( false);
			else
				m_waterReflection.SetActive( true);
		}

		GUILayout.Space( gapSize);
		if( GUILayout.Button( "Toggle Transparent", heightOption))
		{
			LayerMask tp = LayerMask.NameToLayer("TransparentFX");
			int mask = 1<<tp.value;
			if( (Camera.main.cullingMask & mask) != 0)
			{
				Camera.main.cullingMask &= ~mask;
			}
			else
				Camera.main.cullingMask |= tp;

		}
		*/
//		GUILayout.Space( gapSize);
//		if( GUILayout.Button( "Toggle Effect", heightOption))
//		{
//			LayerMask tp = LayerMask.NameToLayer("Effect");
//
//			int mask = 1<<tp.value;
//			if( (Camera.main.cullingMask & mask) != 0)
//			{
//				Camera.main.cullingMask &= ~mask;
//			}
//			else
//				Camera.main.cullingMask |= mask;
//			
//		}
/*
		GUILayout.Space( gapSize);
		if( GUILayout.Button( "Toggle AutoPlay", heightOption))
		{
			AutoPlayer.Instance.m_bAutoPlayMode = !AutoPlayer.Instance.m_bAutoPlayMode;
		}
		GUILayout.Space( gapSize);
		AutoPlayer.Instance.m_autoPlayResponseTime = GUILayout.HorizontalSlider( AutoPlayer.Instance.m_autoPlayResponseTime, 0.1f, 0.5f);

		GUILayout.Space( gapSize);
		if( GUILayout.Button( "Hide This", heightOption))
		{
			gameObject.SetActive( false);
		}

		GUILayout.EndArea();

		GUILayout.BeginArea( new Rect( Screen.width-100, 100, 100, 200));

		GUILayout.Space( gapSize);
		if( GUILayout.Button( "Inc ViewSize:"+m_TSM.CameraSizeDefault, heightOption))
		{
			m_TSM.CameraSizeDefault += 0.2f;

			m_TSM.m_Camera.camera.orthographicSize = m_TSM.CameraSizeDefault;
			
		}
		GUILayout.Space( gapSize);
		if( GUILayout.Button( "Dec ViewSize", heightOption))
		{
			m_TSM.CameraSizeDefault -= 0.2f;
			
			m_TSM.m_Camera.camera.orthographicSize = m_TSM.CameraSizeDefault;
			
		}

		GUILayout.Space( gapSize);
		int targetFrameRate = Application.targetFrameRate;
		if( GUILayout.Button( "Framerate:"+targetFrameRate, heightOption))
		{
			if( targetFrameRate <= 0)
				Application.targetFrameRate = 30;
			else if( targetFrameRate == 30)
				Application.targetFrameRate = 60;
			else
				Application.targetFrameRate = 0;
		}
*/
		GUILayout.EndArea();

	}
}