using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GameSocket
{
	public class SocketClient
	{
		private const int bufferSize = 1024*10;
		private Socket currentSocket;

		public event EventHandler<DataRecvEventArgs> DataRecvHandler;
		public event EventHandler<ConnectOkEventArgs> ConnectOkHandler;
		public event EventHandler ConnectCloseHandler;
		public event EventHandler ConnectErrorHandler;
		public event EventHandler ReconnectHandler;

		public void ConnectServer(string serverAddr, int port)
		{
			if (null != this.currentSocket && this.currentSocket.Connected)
			{
				return;
			}
			this.currentSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			this.currentSocket.NoDelay = true;
			IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(serverAddr), port);
			this.currentSocket.BeginConnect(endPoint, new AsyncCallback(this.OnConnectComplete), this.currentSocket);
		}

		public void Disconnect()
		{
			if (this.currentSocket != null && this.currentSocket.Connected)
			{
				this.currentSocket.Shutdown(SocketShutdown.Both);
				this.currentSocket.Close();
				this.currentSocket = null;
			}
		}

		public void SendData(byte[] data)
		{
			if (null == this.currentSocket || !this.currentSocket.Connected)
			{
				if (null != this.ReconnectHandler)
				{
					this.ReconnectHandler(this, new EventArgs());
				}
				return;
			}
			this.currentSocket.BeginSend(data, 0, data.Length, SocketFlags.None, 
			                             new AsyncCallback(this.OnSendComplete), this.currentSocket);
		}

		private void OnSendComplete(IAsyncResult result)
		{
			this.currentSocket.EndSend(result);
		}

		private void OnConnectComplete(IAsyncResult result)
		{
			try
			{
				if (null != this.ConnectOkHandler)
				{
					this.ConnectOkHandler(this, new ConnectOkEventArgs(true));
				}
				this.currentSocket.EndConnect(result);
				byte[] array = new byte[bufferSize];
				this.currentSocket.BeginReceive(array, 0, bufferSize, SocketFlags.None, new AsyncCallback(this.KeepConnect), array);
			}
			catch(SocketException)
			{
				if (null != this.ConnectErrorHandler)
				{
					this.ConnectErrorHandler(this, new EventArgs());
				}
			}
		}

		private void KeepConnect(IAsyncResult result)
		{
			int num = this.currentSocket.EndReceive(result);
			if (num > 0)
			{
				byte[] array = (byte[])result.AsyncState;
				if (null != this.DataRecvHandler && null != array)
				{
					this.DataRecvHandler(this, new DataRecvEventArgs(array, num));
				}
				array = new byte[bufferSize];
				this.currentSocket.BeginReceive(array, 0, bufferSize, SocketFlags.None, 
				                                new AsyncCallback(this.KeepConnect), array);
			}
		}
	}
	
	public class ConnectOkEventArgs : EventArgs
	{
		public bool ConnectOk = false;
		public ConnectOkEventArgs(bool connectOk)
		{
			this.ConnectOk = connectOk;
		}
	}
	
	public class DataRecvEventArgs : EventArgs
	{
		public byte[] Data;
		public int DataSize;

		public DataRecvEventArgs(byte[] data, int dataSize)
		{
			this.Data = data;
			this.DataSize = dataSize;
		}
	}

	public abstract class ServerMessageHandler
	{
		public abstract void OnMessage(Int16 messageType, byte[] data);
	}
	
	public class ServerMessageDispatcher
	{
		private struct SocketData {
			public byte[] Data;
			public int Size;
		}
		
		private const int packetMaxLength = 1024*10;
		private int writeIndex = 0;
		private byte[] buffer;
		private Queue dataQueue = new Queue();
		private Dictionary<int, ServerMessageHandler> messagehandlers = new Dictionary<int, ServerMessageHandler>();
		
		public ServerMessageDispatcher()
		{
			this.buffer = new byte[packetMaxLength];
		}

		public void Update()
		{
			while (this.dataQueue.Count > 0)
			{
				SocketData socketdata = (SocketData)this.dataQueue.Dequeue();
				this.parseData(socketdata.Data, socketdata.Size);
			}
		}

		public void AddData(byte[] data, int size)
		{
			SocketData socketdata = new SocketData();
			socketdata.Data = data;
			socketdata.Size = size;
			dataQueue.Enqueue(socketdata);
		}

		public void RegisterMessageHandler(int messageType, ServerMessageHandler messageHandler)
		{
			this.messagehandlers.Add(messageType, messageHandler);
		}
		
		public void UnregisterMessageHandler(int messageType)
		{
			this.messagehandlers.Remove(messageType);
		}


		private void parseData(byte[] data, int actualSize) 
		{
			if (this.writeIndex + actualSize >= packetMaxLength) 
			{
				throw new Exception( "Buffer Overflow!");
			}
			Array.Copy( data, 0, this.buffer, this.writeIndex, actualSize);
			this.writeIndex += actualSize;
			if(writeIndex < 1)
			{
				return;
			}
//			int len = BitConverter.ToUInt16( this.buffer, 0);
			int len = (this.buffer[0] << 8) + this.buffer[1];
			while (this.writeIndex >= 1 && this.writeIndex >= len - 1) 
			{
				byte[] result = new byte[len-2];
				int messageType = (this.buffer[2] << 8) + this.buffer[3];
				Array.Copy( this.buffer, 4, result, 0, len-2);
				this.buffer = this.remove( this.buffer, ref this.writeIndex, len);
				this.dispatchMessage(messageType, result);
//				len = BitConverter.ToUInt16( this.buffer, 0);
				len = (this.buffer[0] << 8) + this.buffer[1];
			}
		}
		
		private byte[] remove( byte[] data, ref int writeIndex, int len) 
		{
			byte[] newBuffer = new byte[packetMaxLength];
			Array.Copy( data, len, newBuffer, 0, writeIndex + 1 - len);
			writeIndex -= len;
			return newBuffer;
		}

		private void dispatchMessage(int messageType, byte[] data)
		{
			if(this.messagehandlers.ContainsKey(messageType) == false)
				return;

			ServerMessageHandler messageHandler = this.messagehandlers[messageType];
			if (null != messageHandler)
			{
				messageHandler.OnMessage((Int16)messageType, data);
			}
		}
	}
}


