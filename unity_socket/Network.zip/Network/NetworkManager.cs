﻿using UnityEngine;
using System.Collections;

public class NetworkManager : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}


	void OnGUI()
	{
		GUILayoutOption heightOption = GUILayout.Height( 50);
		if( !Network.isServer && !Network.isClient)
		{

			// start server
			GUILayout.BeginArea( new Rect( 100, 100, 100, 400));

			if( GUILayout.Button( "Start a room", heightOption))
				InitServer();

			if( GUILayout.Button ( "Refresh room list", heightOption))
			{
				MasterServer.RequestHostList( gameTypeName);
			}

			GUILayout.EndArea();

			// room list
			if( hostList != null)
			{
				GUILayout.BeginArea( new Rect( 300, 100, 100, 400));
				foreach( HostData host in hostList)
					if( GUILayout.Button( host.gameName, heightOption))
						Join( host);
				GUILayout.EndArea();
			}
		}

	}

	#region SERVER

	string gameTypeName = "PunchPVP";
	string gameName = "myGame";
	void InitServer()
	{
		Network.InitializeServer( 2, 25000, !Network.HavePublicAddress());
	}

	void OnServerInitialized()
	{
		MasterServer.RegisterHost( gameTypeName, gameName+Random.Range(0, 1000)); 
	}

	void OnFailedToConnectToMasterServer()
	{
	}
	#endregion

	#region CLIENT
	HostData[] hostList;
	void OnMasterServerEvent( MasterServerEvent e)
	{
		switch( e)
		{
		case MasterServerEvent.HostListReceived:
			hostList = MasterServer.PollHostList();
			break;
		}
	}

	void Join( HostData host)
	{
		Network.Connect( host);
	}

	void OnConnectedToServer()
	{
	}
#endregion
}
