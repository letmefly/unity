﻿using UnityEngine;
using System.Collections;

public class PVPManager : MonoBehaviour {

	public static PVPManager Instance;

	
	public GameObject playerPrefab;


	void Awake()
	{
		Instance = this;
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	int entryCount;

	[RPC]
	void ClientJoined()
	{
		state = State.ClientJoined;

		// do some stuffs

		// start battle..
		state = State.Battle;
		StartBattle();
	}

	[RPC]
	void ServerCreated()
	{
		state = State.ServerCreated;
	}

	enum State {
		Init,
		ServerCreated,
		ClientJoined,
		Battle,
	}
	State state;

	public void Enter()
	{
		entryCount++;

		if( Network.isClient)
		{
			state = State.Init;
			StartCoroutine( Join());
		}
		else if( Network.isServer)
		{

			networkView.RPC( "ServerCreated", RPCMode.All);
		}


	}

	IEnumerator Join()
	{
		while( true)
		{
			if( state == State.ServerCreated)
			{
				networkView.RPC( "ClientJoined", RPCMode.All);

				return true;
				//yield return 0;
			}
			else 
				yield return new WaitForSeconds( 0.1f);
		}
	}

	void StartBattle()
	{
		// sync hero
		if( IsHero)
		{
			NetworkView nv = GameManager.Instance.m_Hero.GetComponent<NetworkView>();
			nv.viewID = Network.AllocateViewID();

			networkView.RPC ( "SyncHero", RPCMode.Others, nv.viewID);
		}
	}

	[RPC]
	void SyncHero( NetworkViewID viewID)
	{
		NetworkView nv = GameManager.Instance.m_Hero.GetComponent<NetworkView>();
		nv.viewID = viewID;
	}

	public static bool IsHero {
		get {
			return Network.isServer;
		}
	}
	
}
