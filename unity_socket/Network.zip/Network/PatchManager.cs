#define USE_WWW_LoadFromCacheOrDownload
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PatchManager : MonoBehaviour {
	public static string patchFileName ="patch_4_0"; // "patch_4_0.IPhonePlayer_89.unity3d";

//	string PatchInfoUrl = "http://devofdpimg.tangentkorea.com/patch/patch";
//	string PatchInfoUrl = "http://gdhimg.tangentkorea.com/patch/ofdp_down/patch";
//	string PatchInfoUrl = "http://skymobiimg.tangentkorea.com/patch/ofdp_down/" + patchFileName;
//#if UNITY_IOS
//	string PatchInfoUrl = "http://itdownload.miyigame.com:35001/ofdproot/images/patch/{0}_v{1}/" + patchFileName;
//#else
//	string PatchInfoUrl = "http://itdownload.miyigame.com:35001/ofdproot/images/patch/360_v21/" + patchFileName;
//#endif
	string PatchInfoUrl = "http://itdownload.miyigame.com:35001/ofdproot/images/patch/{0}_v{1}/" + patchFileName;

	static Dictionary<string,WWW> m_items = new Dictionary<string, WWW>();
	
	public enum STATUS {
		DONE,
		ERROR,
		DOING,
		Doing2,
		INIT,
	}

	public static STATUS m_status = STATUS.INIT;

	static int patchVersion;

	void Awake()
	{
		GameObject.DontDestroyOnLoad( this);

		if( m_status != STATUS.DONE)
			StartCoroutine( Patch ());
        
	}

	float wwwSent;

    // Use this for initialization
	IEnumerator Patch ()
	{
#if! USE_WWW_LoadFromCacheOrDownload
		Caching.CleanCache();
#endif

		m_status = STATUS.INIT;

		string platform = RuntimePlatform.WindowsPlayer.ToString();
		string baseUrl = PatchInfoUrl;
#if UNITY_ANDROID
		platform = RuntimePlatform.Android.ToString();
#elif UNITY_IPHONE
		platform = RuntimePlatform.IPhonePlayer.ToString();
#endif
		baseUrl = string.Format(baseUrl, IABManager.Instance.GetChannelName(), ServerManager.version);

		wwwSent = Time.time;

		WWW www = new WWW(string.Format("{0}.{1}.html?timestamp={2}", baseUrl, platform.ToString(), System.DateTime.Now.Ticks));
		//WWW www = new WWW( "http://172.16.12.157/images/patch/ofdp_down/patch_4_0.IPhonePlayer_89.unity3d");
		//http://172.16.12.157/images/patch/ofdp_down/patch_4_0.IPhonePlayer.html
		//WWW www = new WWW( "http://skymobiimg.tangentkorea.com/patch/ofdp_down/");
		yield return www;

		Debug.Log ( www.url);

		m_status = STATUS.DOING;


		if( www.error == null)
   		{
			string[] lines = www.text.Split( new char[] { '\n'}, System.StringSplitOptions.RemoveEmptyEntries);
			foreach( string line in lines)
			{
				string[] tokens = line.Split( new char[] { ','}, System.StringSplitOptions.RemoveEmptyEntries);

				string url = tokens[0].Trim();
				Debug.Log("url: " + url);
				patchVersion = int.Parse( tokens[1]);

				Debug.Log ( line);

#if USE_WWW_LoadFromCacheOrDownload
				WWW item = WWW.LoadFromCacheOrDownload( url, patchVersion);
#else
				WWW item = new WWW(url);
#endif

		m_status = STATUS.Doing2;

				yield return item;
				if( item.error == null)
				{
					string name = System.IO.Path.GetFileNameWithoutExtension( url);
					m_items[name] = item;
				}
				else
				{
					OnError(url, item.error);
				}
        	}

			if( m_items.Count == lines.Length)
				m_status = STATUS.DONE;

		}
		else
		{
			OnError(www.url, www.error);
		}
    }

	void OnError(string errorUrl, string error)
	{
		m_status = STATUS.ERROR;

		if( Application.internetReachability != NetworkReachability.NotReachable)// for guest login
		{
			if( UILogin.Instance != null)
			{

				string errorText = error;
	#if UNITY_EDITOR
				errorText = errorUrl+"\n"+error;
	#endif
				UILogin.Instance.PopupDialog.OpenTwoBtnPopup( Locale.Get("~NetworkError", errorText), delegate(bool isOk) {
					if(!isOk)
						Application.Quit();
				});

			}
		}
	}

 	public static bool IsDone()
	{
		return m_status == STATUS.DONE;
	}
	/*
	public static AssetBundle GetAssetBundle( string name)
	{
		return m_items[name].assetBundle;
	}
*/

	public static Object GetPatchItem( string name)
	{
		//return GetAssetBundle(name).mainAsset;
		foreach( KeyValuePair<string,WWW> kv in m_items)
		{
			Object obj = kv.Value.assetBundle.Load( name);
			if( obj != null)
				return obj;
		}

		return null;
	}

    void Update()
    {
		//Debug.Log ( m_status);
		if( m_status == STATUS.ERROR)
		{
			StartCoroutine( Patch ());
		}
		else if( m_status == STATUS.INIT)
		{
			if( Time.time - wwwSent > 10.0f)
			{
				Debug.Log( "STATUS.INIT timeout");
				StartCoroutine( Patch ());
			}
		}
    }

}
