﻿using UnityEngine;
using System.Collections;
using System.Text;

public class PushManager : MonoBehaviour {

    static PushManager _instance;

	public static PushManager Instance
	{
		get{
			if( _instance == null )
			{
				_instance = new GameObject("PushManager").AddComponent<PushManager>();    
			}

			return _instance;
		}
	}

    
#if UNITY_ANDROID
//	AndroidJavaClass cls_UnityPlayer;
//	AndroidJavaObject obj_Activity;
	AndroidJavaClass GCMPlugin;
#endif
    private string GCMID = "";
    private string message;
    private string type;

    public string GetPushID()
    {
        return GCMID;
    }

    // Use this for initialization
    void Awake ()
    {
#if UNITY_EDITOR

#elif UNITY_ANDROID
//		cls_UnityPlayer = new AndroidJavaClass ("com.unity3d.player.UnityPlayer");          //Grabs the Android Unity Player
//       obj_Activity = cls_UnityPlayer.GetStatic<AndroidJavaObject> ("currentActivity");    //Grabs current Android activity
//		GCMPlugin = new AndroidJavaClass("com.tangent.unitygcmplugin.GCMPlugin");

        /*
         *In order to use GCM on this device you must register the device with the GCM server
         *YourProjectIDHere is where you would put the Project ID that is given by the Google API Console
         *You can learn more about Google Cloud Messaging by visiting the GCM website: http://developer.android.com/google/gcm/index.html
         */

//		GCMPlugin.CallStatic ("registerDeviceWithGCM", new object[]{"255602735920"});
        
#elif UNITY_IPHONE
        NotificationServices.RegisterForRemoteNotificationTypes(RemoteNotificationType.Alert | 
                                                                RemoteNotificationType.Badge | 
                                                                RemoteNotificationType.Sound);
        
#endif
    }

    void Update()
    {
#if UNITY_IPHONE
/*
        if(string.IsNullOrEmpty(GCMID))
            GCMID = NotificationServices.deviceToken.ToString();
*/
#endif

    }


#if UNITY_ANDROID
    public void GCMReceiver (string gcmMessage)
    {
        string[] tmp = gcmMessage.Split (';');
    
        if (gcmMessage.Contains ("GCMRegistered")) {
			GCMID = GCMPlugin.CallStatic<string> ("getGcmRegID");  
            Util.DebugLog("Miru - getGcmRegID : " + GCMID);
			PlayerInfo.Instance.SendPushID(GCMID);
            
        } else {
            string[] type = tmp [4].Split ('=');
            string[] msg = tmp [1].Split ('=');
            switch (type [1]) {
            case "UpdatePlayerInfo":
                this.message = this.message + "\n" + msg [1];
                break;
        
            }
        }

    }

 	public void AddLocalPush(int id, string msg, float afterSecs, bool closeLocal = false)
	{
//		try {
//			
//			AndroidJavaClass playerClass = new AndroidJavaClass(GoogleMobileAds.Android.Utils.UnityActivityClassName);
//			AndroidJavaObject activity =
//				playerClass.GetStatic<AndroidJavaObject>("currentActivity");			
//			
//			AndroidJavaObject alarmManager = activity.Call<AndroidJavaObject>( "getSystemService", "alarm");
//			
//			// RTC_WAKEUP
//            System.DateTime alarmTime = System.DateTime.UtcNow.AddSeconds( afterSecs);
//            System.TimeSpan span = alarmTime.Subtract(new System.DateTime(1970,1,1,0,0,0));
//            //long showMillis = System.DateTime.Now.Ticks + (long)(afterSecs * 1000);
//
//			AndroidJavaClass pendingIntentClass = new AndroidJavaClass("android.app.PendingIntent");
//			
//			//		AndroidJavaClass GCMMyBoadcastReceiverClass = new AndroidJavaClass("com.tangent.unitygcmplugin.GCMMyBoadcastReceiver");
//			//GCMMyBoadcastReceiverClass.GetStatic<>("class")
//			AndroidJavaObject intent = new AndroidJavaObject("android.content.Intent", "com.google.android.c2dm.intent.RECEIVE");
//			intent.Call<AndroidJavaObject>("setClassName", activity, "com.tangent.unitygcmplugin.LocalNotification");
//            intent.Call<AndroidJavaObject>( "putExtra", "RequestCode", id);
//            intent.Call<AndroidJavaObject>( "putExtra", "EndTimeMillis", (long)span.TotalMilliseconds);
//			intent.Call<AndroidJavaObject>( "putExtra", "title", "OFDP");
//			intent.Call<AndroidJavaObject>( "putExtra", "msg", msg);
//            intent.Call<AndroidJavaObject>( "putExtra", "Cancel", closeLocal);
//
//            AndroidJavaObject pendingIntent;
//			//	pendingIntent = pendingIntentClass.CallStatic<AndroidJavaObject>( "getBroadcast", activity, (int)0, intent, (int)536870912);
//			
//			//	Debug.Log ( "pendingIntent:"+pendingIntent.ToString());
//			
//			AndroidJavaObject componentName = intent.Call<AndroidJavaObject> ( "getComponent");
//			
//			Util.DebugLog(" ClassName :" + componentName.Call<string>( "getClassName"));
//
//            pendingIntent = pendingIntentClass.CallStatic<AndroidJavaObject>("getBroadcast", activity, id, intent, (int)268435456);
//			
//			//Debug.Log ( "pendingIntent:"+pendingIntent.ToString());
//			//Debug.Log ( "span.TotalMilliseconds:"+span.TotalMilliseconds);
//            
//			alarmManager.Call ( "set", (int)0, (long)span.TotalMilliseconds, pendingIntent);
//
//			//Debug.Log ( "AddLocalPush:"+alarmTime);
//		}
//		catch( System.Exception e)
//		{
//			Debug.Log ( e.Message);
//		}
	}
#else
	public void AddLocalPush( int id, string msg, float afterSecs, bool closeLocal = false)
	{
	}
#endif

    /*
	void OnApplicationPause(bool bPause)
	{
		if (bPause)
		{
			System.DateTime fullTime =  PlayerInfo.Instance.GetStaminaFullTime();
			Debug.Log ( fullTime);
			System.TimeSpan span = fullTime.Subtract( System.DateTime.Now);
			if( span.TotalSeconds > 0)
				AddLocalPush( "Come and fight!", (float)span.TotalSeconds);
		}
	}
	*/
    
}
