﻿using UnityEngine;
using System.Collections;
using System.Text;

public class RC4Crypt{

	static byte[] EnDeCrypt(string prm_key, byte[] prm_text)
	{
		int N = 256;
		int[] sbox = new int[N];
		int[] key = new int[N];
		int n = prm_key.Length;
		for (int a = 0; a < N; a++)
		{
			key[a] = (int)prm_key[a % n];
			sbox[a] = a;
		}
		
		int b = 0;
		for (int a = 0; a < N; a++)
		{
			b = (b + sbox[a] + key[a]) % N;
			int tempSwap = sbox[a];
			sbox[a] = sbox[b];
			sbox[b] = tempSwap;
		}
		
		int i = 0, j = 0, k  = 0;
//		StringBuilder cipher = new StringBuilder();
		byte[] cipher = new byte[prm_text.Length];
		for (int a = 0; a < prm_text.Length; a++)
		{
			i = (i + 1) % N;
			j = (j + sbox[i]) % N;
			int tempSwap = sbox[i];
			sbox[i] = sbox[j];
			sbox[j] = tempSwap;
			
			k = sbox[(sbox[i] + sbox[j]) % N];
			cipher[a] = (byte)(prm_text[a] ^ k);
//			int cipherBy = ((int)prm_text[a]) ^ k;  //xor operation
//			cipher.Append(System.Convert.ToChar(cipherBy));
		}
		return cipher;//.ToString();
	}

	public static string EncryptRC4(string prm_key, string prm_text)
	{
/*		string Text = EnDeCrypt(prm_key, prm_text);//WWW.EscapeURL(prm_key), prm_text);

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < Text.Length; i++)
		{
			int v = System.Convert.ToInt32(Text[i]);
			sb.Append(string.Format("{0:X2}", v));
		}

		return sb.ToString();
*/
		return System.Convert.ToBase64String(EnDeCrypt(prm_key, Encoding.UTF8.GetBytes(prm_text)));
	}

	public static string DecryptRC4(string prm_key, string prm_text)
	{

/*		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < prm_text.Length; i += 2)
		{
			int n = System.Convert.ToInt32(prm_text.Substring(i, 2), 16);
			sb.Append(System.Convert.ToChar(n));
		}

		return EnDeCrypt(prm_key, sb.ToString());//WWW.UnEscapeURL(EnDeCrypt(prm_key, sb.ToString()));
*/
		return Encoding.UTF8.GetString(EnDeCrypt(prm_key, System.Convert.FromBase64String(prm_text)));
	}
}
