using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using Json=LitJson.JsonData;
using System.Reflection;
using GameSocket;

public class ServerManager : MonoBehaviour
{
	public const int version = 21;
	public static ServerManager Instance;
	CustomNetwork network = new CustomNetwork();
	public bool m_DevServer = false;
	public static string m_NewDomain = "";

	public static CustomNetwork  Network 
	{
		get { return Instance.network;}
	}

	public static void ResetBaseUrl(string url)
	{
	}
	public static void ResetBaseUrl()
	{
	}

	void Awake()
	{
		Instance = this;
	}

	void Update () 
	{
		network.Update();
	}
}


public class HttpNetwork
{
	public static bool offlineMode = false;
	public string m_baseUrl = "";
	private ServerMessageDispatcher messageDispatcher;
	private SocketClient socketClient;
	public delegate void Callback(Packet p);
	public class Packet : ServerMessageHandler
	{
		public string m_url;
		public static int sended;
		public static int received;
		public int ERROR;
		private Int16 messageType;
		public string ERROR_MESSAGE;
		public object objectToSend;
		Callback callback;
		public string LOCALIZED_ERROR_MESSAGE {
			get {
				return Locale.Get(ERROR.ToString());
			}
		}
		public void Set( object o, Callback cb) 
		{
			this.objectToSend = o;
			this.callback = cb;
		}

		public void SetMessageType(Int16 messageType)
		{
			this.messageType = messageType;
		}
		public object GetSendingObject()
		{
			return objectToSend;
		}

		public override void OnMessage (Int16 messageType, byte[] data)
		{
			// 64decode, desdecode
			string dataStr = System.Text.Encoding.Default.GetString(data);
			Packet responsePacket = this;
			LitJson.JsonMapper.ToObject(responsePacket, dataStr);
			this.callback(responsePacket);
		}

		public string DECODED_ERROR_MESSAGE
		{
			get {
				return "network failed";
			}
		}
		public void RebuildWWW()
		{
		}
		public WWW GetWWW()
		{
			return new WWW( m_url, new Byte[1000]);
		}
	}

	public int m_packetCount {
		get {
			return 0;
		}
	}
	public void SetOfflineFunc(Callback func)
	{
	}
	public void SetBaseUrl( string url)
	{
		m_baseUrl = url;
	}


	public HttpNetwork()
	{
		this.messageDispatcher = new ServerMessageDispatcher();
		this.socketClient = new SocketClient();
		this.socketClient.DataRecvHandler += new EventHandler<DataRecvEventArgs>(this.DataRecvHandler);
		this.socketClient.ConnectOkHandler += new EventHandler<ConnectOkEventArgs>(this.ConnectOkHandler);
		this.socketClient.ConnectCloseHandler += new EventHandler(this.ConnectCloseHandler);
		this.socketClient.ConnectErrorHandler += new EventHandler(this.ConnectErrorHandler);
		this.socketClient.ConnectServer("127.0.0.1", 8888);
	}

	private void DataRecvHandler(object sender, DataRecvEventArgs e)
	{
		this.messageDispatcher.AddData(e.Data, e.DataSize);
	}

	private void ConnectOkHandler(object sender, ConnectOkEventArgs e)
	{
	}

	private void ConnectCloseHandler(object sender, EventArgs e)
	{
	}

	private void ConnectErrorHandler(object sender, EventArgs e)
	{
	}

	public void Update()
	{
		this.messageDispatcher.Update();
	}


	public void SendWithParams(string url, Callback cb, Packet p, params object[] args)
	{
		p = CreatePacket(cb, p, args);
		string jsonString = (string)p.objectToSend;
		byte[] jsonByteArray = System.Text.Encoding.Default.GetBytes(jsonString);
		Int16 messageType = getMessageTypeByUrl(url);
		p.SetMessageType(messageType);
		int messageLen = jsonByteArray.Length+2;
		int packageLen = messageLen + 2;
		if (packageLen > 10*1024) {return;}
		byte[] packageByteArray = new byte[packageLen];
		packageByteArray[0] = (byte)((messageLen & 0xFF00)>>8);
		packageByteArray[1] = (byte)(messageLen & 0xFF);
		packageByteArray[2] = (byte)((messageType & 0xFF00)>>8);
		packageByteArray[3] = (byte)(messageType & 0xFF);
		Array.Copy(jsonByteArray, 0, packageByteArray, 4, jsonByteArray.Length);
		this.messageDispatcher.RegisterMessageHandler(messageType, p);
		this.socketClient.SendData(packageByteArray);
	}

	protected virtual void OnError(Packet p)
	{
	}

	protected virtual void DiffaultOfflineFunc(Packet p)
	{
	}

	private Int16 getMessageTypeByUrl(string url)
	{
		return 1;
	}

	public static Json BuildJsonFromEnumerable( IEnumerable enumerable)
	{
		LitJson.JsonData array = new LitJson.JsonData();
		array.SetJsonType( LitJson.JsonType.Array);
		foreach( object o in enumerable)
		{
			array.Add ( o);
		}
		return array;
	}

	Packet CreatePacket(Callback cb, Packet p, object[] args)
	{
		Json json = new Json();
		for( int i = 0; i < args.Length; i+=2)
		{
			object parameter = args[i+1];
			if( parameter is Json)
				json[args[i].ToString()] = parameter as Json;
			else if( parameter is Array)
			{
				json[args[i].ToString()] = BuildJsonFromEnumerable( parameter as IEnumerable);
			}
			else
			{
				json[args[i].ToString()] = new Json( parameter);
			}
		}
		p.Set(json.ToJson(), cb);	
		return p;
	}
	
//	protected static byte[] Serialize( string t)
//	{
//	}
//	
//	protected static string Deserialize( string t)
//	{
//	}

	//------------------------ protocal struct --------------------------
	public class MONEYPACKET : Packet {
		public long money;
		public long cash;
		public int lotteryPoint;
		public int lotteryHighCoupon;
		public int lotteryCoupon;
		public int heart;
		public string heartTime;
		public int heartTimeSeconds;
	}
	
	public class BUYITEMPACKET : MONEYPACKET {
		public int vipRemainSeconds;
	}
	
	public class LOGIN : MONEYPACKET {
		public string notice;
		public int version;
		public int userID;
		public string nickname;
		
		public int popup;
		public string popupText;
		
		public int bannerID;
		public string bannerImageURL;
		public string bannerLinkURL;
		public int tutorial;
		public int review;
		public int inviteCount;
		public int agreeMessage;
		
		public int level;
		public int exp;
		
		public int attendanceReward;
		public int attendanceCount;
		public int attendanceDays;
		
		public int skillSlot;
		public int treasureSlot;
		public int treasureInventory;
		
		public ServerItemInfo[] characters;
		public ServerItemInfo[] skills;
		public ServerItemInfo[] treasures;
		
		public ShopItemInfo[] shop;
		
		public ClearedStageInfo[] stages;
		
		public MissionInfo[] missions;
		
		public LeagueInfo league;
		
		//		public NOTICEInfo[] notice;
		
		public BoosterItemInfo[] items;
		public AchievementInfo[] achievements;
		
		public int messsagecount;
		public int vipRemainSeconds;
		public int videoRebornTimes;
		public int watchVideoTimes;
		public int development;
		
		public bool daliyEventActive;
		public long servertime;
	}
	
	public class AchievementInfo {
		public int a;//achieveOriginalID
		public int p;//progress
		public int r;//reward
	}
	
	public class LeagueInfo{
		public int score;
		public int grade;
		public int groupID;
		public int rank;
	}
	
	public class ShopItemInfo{
		public string p;//productID
		public int i;//itemID
		public int a;//amount
		public int ma;//moreAmount
		public int mp;//morePercentage
		public int c;//count
	}
	
	public class ServerItemInfo {
		public int i;//itemID
		public string o;//itemOriginalID
		public int l;//level
		
		public int s;//slot
	}
	
	public class ClearedStageInfo {
		public int i;//stageID
		public int c;//isClear
		public int cc;//clearCount
		public int s;//bestScore
		public int p;//isPerfect
	}
	
	public class MissionInfo{
		public int m;//missionID
		public int i;//missionOriginalID
		public int c;//isClear
	}
	
	public class MessageInfo
	{
		public int messageID;
		public int userID;
		public string nickname;
		public int giftType;
		public int itemID;
		public int amount;
		public string text;
		//		public DateTime sendDate;
		public int receiveLimitTime;
	}
	
	public class NOTICEInfo
	{
		public string title;
		public string url;
		public DateTime createDate;
	}
	
	public class ITEMLIST : MONEYPACKET {
		public ServerItemInfo[] list;
	}
	
	public class BUYARTIFACT : ITEMLIST {
		public int treasureID;
		public int buyID;
	}
	
	public class GATCHA : MONEYPACKET {
		public int itemID;
		public int itemOriginalID;
		public int buyID;
	}
	
	public class UPGRADEITEM : ITEMLIST {
		public int upgrade;
	}
	
	public class GAMESTART : Packet {
		public int playCode;
		public int[] slotSkills;
		public int[] slotTreasures;
		public FriendInfo friend;
	}
	
	public class GAMERESULT : MONEYPACKET
	{ //FRIENDPOINTPACKET
		public int	level;
		public int	exp;
		public GameResultReward reward;
		public GameResultGradeReward[] gradeReward;
		public BoosterItemInfo[] items;
	}	
	
	public class GameResultGradeReward {
		public int type;
		public int amount;
		public int itemID;
	}
	
	public class GameResultReward {
		public int type;
		public int amount;
		public int itemID;
	}
	
	public class MESSAGELIST : MONEYPACKET {
		public MessageInfo[] messages;
	}
	
	public class MESSAGELISTRECEIVE : MONEYPACKET {
		public int level;
		public int exp;
		//public MessageInfo[] messages;
		public BoosterItemInfo[] items;
	}
	
	public class RankInfo{
		public int rank;
		public int userID;
		public string nickname;
		public int score;
		public int level;
		public ServerItemInfo character;
	}
	
	public class RANKLIST : MONEYPACKET {
		public RankInfo[] ranking;
		public RankInfo my;
		public LeagueInfo league;
		public LeagueInfo lastLeague;
		//		public DateTime nextLeagueDate;
		public int nextLeagueTime;
	}
	
	public class FriendInfo{
		public int userID;
		public string nickname;
		public int score;
		public int level;
		public int agreeMessage;
		//		public DateTime loginDate;
		public int loginDateTime;
		//		public DateTime recentMessageDate;
		public int recentMessageDateTime;
		//		public DateTime playDate;
		public int playDateTime;
		public ServerItemInfo character;
		public ServerItemInfo[] skills;
		public ServerItemInfo[] treasures;
	}
	
	public class FRIENDLIST : Packet {
		public FriendInfo[] friends;
		public FriendInfo[] waitings;
	}
	
	public class FRIENDFINDLIST : Packet {
		public FriendInfo[] users;
	}
	
	public class UserDetailInfo{
		public string nickname;
		public int level;
		public int score;
		public int bestCcore;
		public int leagueGrade;
		//		public DateTime loginDate;
		//		public int loginDateTime;
		public ServerItemInfo character;
		public ServerItemInfo[] skills;
		public ServerItemInfo[] treasures;
	}
	
	public class USERDETAIL : Packet {
		public UserDetailInfo detail;
	}
	
	public class BUYTREASUREINVEN : MONEYPACKET
	{ 
		public int treasureInventory;
	}
	
	public class BoosterItemInfo {
		public int instantItemID;
		public int randomItemID;
		public int amount;
	}
	
	public class BOOSTERITEMLIST : MONEYPACKET {
		public BoosterItemInfo[] list;
	}
	
	public class LOTTERY : MONEYPACKET {
		public LottertItem reward;
		public BoosterItemInfo[] items;
	}
	
	public class LottertItem{
		public int type;
		public int amount;
		public int itemID;
	}
	
	public class TUTORIAL : MONEYPACKET
	{ 
		public int	tutorial;
		public ServerItemInfo[]	list;
	}	
	
	public class LOBBY : MONEYPACKET
	{ 
		public int attendanceReward;
		public int attendanceCount;
		public int attendanceDays;
		
		public MissionInfo[] missions;
		
		public int messageCount;
		public int friendRequestCount;
	}	
	
	public class ACHIEVEMENT : MONEYPACKET
	{ 
		public AchievementInfo[] achievements;
	}
	
	public class SENDACHIEVEMENT
	{ 
		public string t;//type
		public int c;//count
		
		public SENDACHIEVEMENT(string a, int b)
		{
			t = a;
			c = b;
		}
	}
	
	public class CHECKVESION : Packet
	{ 
		public int	version;
		public string packageURL;
		public int	maintenanceTime;
	}	
	
	public class OfflineInfo{
		public int playCount;
		public int money;
		public int cash;
		public int exp;
		public int usingStamina;
		public int curStamina;
		public int elapsedTime;
		public int tutorial;
		public List<PlayerInfo.ClearStageInfo> clearedStage;
	}
	
	public class BaseUrl : Packet
	{
//		public override bool simpleHttpRequest {
//			get {
//				return true;
//			}
//		}
		public string baseurl = "";
	}

	public static Json BuildJson(object list)
	{
		return LitJson.JsonMapper.ToObject( (LitJson.JsonMapper.ToJson(list)) );
	}
	
	string Call_User_Phonenumber()
	{
		string number = string.Empty;
		
		#if UNITY_ANDROID
		//		AndroidJavaClass cls_TelephonyActivity = new AndroidJavaClass("com.tangent.dungeonhearts.UnityPlayerNativeActivity");
		//		number = cls_TelephonyActivity.CallStatic<string>("Get_num");
		#endif
		
		if(string.IsNullOrEmpty(number))
			number = string.Empty;
		
		return number; 
	}
	
	public void Join( string email, string pw, Callback cb)
	{
		SendWithParams( "user/Join", cb, new Packet(),
		               "email", email, "password", pw, "device", IABManager.Instance.GetDeviceInfo());
	}	
	
	public void JoinP( string email, string pw, Callback cb)
	{
		SendWithParams( "user/JoinProcedure", cb, new Packet(),
		               "email", email, "password", pw, "device", IABManager.Instance.GetDeviceInfo());
	}	
	
	
	public void Login( string email, string pw, OfflineInfo offline, Callback cb)
	{
		int os = 0; 
		int market = 0;
		//string phoneNumber = string.Empty;
		#if UNITY_IPHONE
		os = 1;
		market = 1;
		#elif UNITY_ANDROID
		os = 2;
		market = 2;
		//phoneNumber = Call_User_Phonenumber();
		#endif
		SendWithParams( "user/Login", cb, new LOGIN(),
		               "email", email, "password", pw, "device", IABManager.Instance.GetDeviceInfo(), "os", os, "osVersion", SystemInfo.operatingSystem,
		               "market", IABManager.Instance.GetChannelId(), "pushID", "", "cellphone", "", "language", Localization.language,
		               "offlineInfo", (offline == null) ? "" : LitJson.JsonMapper.ToObject(LitJson.JsonMapper.ToJson(offline)));
		
	}
	
	public void BuyMystiqueSlot( int userID, int slot, Callback cb)
	{
		SendWithParams( "shop/BuySkillSlot", cb, new MONEYPACKET(), 
		               "userID", userID, "slot", slot); 
	}
	
	public void BuyArtifactSlot( int userID, int slot, Callback cb)
	{
		SendWithParams( "shop/BuyTreasureSlot", cb, new MONEYPACKET(), 
		               "userID", userID, "slot", slot); 
	}
	
	public void BuyStance( int userID, int stanceID, Callback cb)
	{
		SendWithParams( "shop/BuyCharacter", cb, new ITEMLIST(), 
		               "userID", userID, "characterOriginalID", stanceID); 
	}
	
	public void BuyMystique( int userID, int itemID, Callback cb)
	{
		SendWithParams( "shop/BuySkill", cb, new ITEMLIST(), 
		               "userID", userID, "skillOriginalID", itemID); 
	}
	
	public void BuyArtifact( int userID, int gradeType, int buyID, string factor, Callback cb)
	{
		SendWithParams( "shop/Gatcha", cb, new GATCHA(), 
		               "userID", userID, "gradeType", gradeType, "buyID", buyID, "factor", factor); 
	}
	
	public void EquipStance( int userID, int itemID, Callback cb)
	{
		SendWithParams( "character/ChangeSlot", cb, new ITEMLIST(), 
		               "userID", userID, "characterID", itemID); 
	}
	
	public void EquipMystique( int userID, int itemID, int slotIndex, Callback cb)
	{
		SendWithParams( "skill/ChangeSlot", cb, new ITEMLIST(), 
		               "userID", userID, "skillID", itemID, "slot", slotIndex); 
	}
	
	public void EquipArtifact( int userID, int itemID, int slotIndex, Callback cb)
	{
		SendWithParams( "treasure/ChangeSlot", cb, new ITEMLIST(), 
		               "userID", userID, "treasureID", itemID, "slot", slotIndex); 
	}
	
	public void UpgradeStance( int userID, int itemID, Callback cb)
	{
		int offline = 0;
		SendWithParams( "character/Upgrade", cb, new ITEMLIST(), 
		               "userID", userID, "characterID", itemID, "offline", offline); 
	}
	
	public void UpgradeMystique( int userID, int itemID, int priceType, string fFactor, Callback cb)
	{
		SendWithParams( "skill/Upgrade", cb, new UPGRADEITEM(), 
		               "userID", userID, "skillID", itemID, "priceType", priceType, "factor", fFactor ); 
	}
	
	public void UpgradeArtifact( int userID, int itemID, int priceType, string fFactor, Callback cb)
	{
		SendWithParams( "treasure/Upgrade", cb, new UPGRADEITEM(), 
		               "userID", userID, "treasureID", itemID, "priceType", priceType, "factor", fFactor ); 
	}
	
	public void SellArtifact( int userID, int itemID, Callback cb)
	{
		SendWithParams( "shop/SellTreasure", cb, new ITEMLIST(), 
		               "userID", userID, "treasureID", itemID); 
	}
	
	public void GameStart( int userID, int stageID, List<int> useItems, int friendID, Callback cb)
	{
		SendWithParams( "game/Start", cb, new GAMESTART(), 
		               "userID", userID, "stageID", stageID, "useItems", BuildJson(useItems), "friendUserID", friendID); 
	}
	
	public void GameResult( int userID, int playcode, int exp, int money, int score, int maxcombo, int isclear, int iPerfect, string dealcode, bool isVideoReborn, Callback cb)
	{
		SendWithParams( "game/Result", cb, new GAMERESULT(),
		               "userID", userID, 
		               "playCode", playcode, 
		               "gainExp", exp, 
		               "gainMoney", money, 
		               "score", score, 
		               "maxCombo", maxcombo, 
		               "isClear", isclear,
		               "isPerfect", iPerfect,
		               "isVideoReborn", isVideoReborn,
		               "dealCode", dealcode);
	}	
	
	public void Mission( int userID, int mission, string fFactor, Callback cb)
	{
		SendWithParams( "game/Mission", cb, new MONEYPACKET(),
		               "userID", userID, 
		               "missionID", mission,
		               "factor", fFactor);
	}	
	
	public void MessageList( int userID, Callback cb)
	{
		SendWithParams( "message/MessageList", cb, new MESSAGELIST(),
		               "userID", userID);
	}	
	
	public void MessageReceive( int userID, int MessageID, Callback cb)
	{
		SendWithParams( "message/Receive", cb, new MESSAGELISTRECEIVE(),
		               "userID", userID,
		               "messageID", MessageID);
	}
	
	public void MessageReceiveAll( int userID, Callback cb)
	{
		SendWithParams( "message/ReceiveAll", cb, new MESSAGELISTRECEIVE(),
		               "userID", userID);
	}
	
	public void RankingList( int userID, Callback cb)
	{
		SendWithParams( "game/Ranking", cb, new RANKLIST(),
		               "userID", userID);
	}
	
	public void FriendList( int userID, Callback cb)
	{
		SendWithParams( "friend/Friends", cb, new FRIENDLIST(),
		               "userID", userID);
	}
	
	public void FriendSuggest( int userID, Callback cb)
	{
		SendWithParams( "friend/Suggest", cb, new FRIENDFINDLIST(),
		               "userID", userID);
	}
	
	public void FriendFind( int userID, string keyword, Callback cb)
	{
		SendWithParams( "friend/Find", cb, new FRIENDFINDLIST(),
		               "userID", userID, "keyword", keyword);
	}
	
	public void FriendDelete( int userID, int friendID, Callback cb)
	{
		SendWithParams( "friend/Remove", cb, new Packet(),
		               "userID", userID, "friendUserID", friendID);
	}
	
	public void FriendGift( int userID, int friendID, Callback cb)
	{
		SendWithParams( "friend/Gift", cb, new MONEYPACKET(),
		               "userID", userID, "friendUserID", friendID);
	}
	
	public void FriendRequestAdmit( int userID, int friendID, Callback cb)
	{
		SendWithParams( "friend/Accept", cb, new Packet(),
		               "userID", userID, "friendUserID", friendID);
	}
	
	public void FriendRequest( int userID, int friendID, Callback cb)
	{
		SendWithParams( "friend/Add", cb, new Packet(),
		               "userID", userID, "friendUserID", friendID);
	}
	
	public void RequestUserDetailInfo( int userID, int detailUserID, Callback cb)
	{
		SendWithParams( "game/UserDetail", cb, new USERDETAIL(),
		               "userID", userID, "detailUserID", detailUserID);
	}
	
	public void BuyTreasureInventory( int userID, Callback cb)
	{
		SendWithParams( "shop/BuyTreasureInventory", cb, new BUYTREASUREINVEN(),
		               "userID", userID);
	}
	
	public void ChangeNickname( int userID, string nick, Callback cb)
	{
		SendWithParams( "user/ChangeNickname", cb, new Packet(),
		               "userID", userID, "nickname", nick);
	}
	
	public void GiveVideoCoin(int userID, Callback cb)
	{
		SendWithParams( "user/RewardWatchVideo", cb, new MONEYPACKET(),
		               "userID", userID);
	}
	
	public void BuyBooster( int userID, int itemID, Callback cb)
	{
		SendWithParams( "shop/BuyInstantItem", cb, new BOOSTERITEMLIST(), 
		               "userID", userID, "itemID", itemID); 
	}
	
	public void Lottery( int userID, Callback cb)
	{
		SendWithParams( "shop/Lottery", cb, new LOTTERY(), 
		               "userID", userID); 
	}
	
	public void Tutorial( int userID, int tutorial, Callback cb)
	{
		SendWithParams( "game/Tutorial", cb, new TUTORIAL(), 
		               "userID", userID, "tutorial", tutorial); 
	}
	
	public void SkillList( int userID, Callback cb)
	{
		SendWithParams( "skill/SkillList", cb, new ITEMLIST(), 
		               "userID", userID); 
	}
	
	public void CharacterList( int userID, Callback cb)
	{
		SendWithParams( "character/CharacterList", cb, new ITEMLIST(), 
		               "userID", userID); 
	}
	
	public void TreasureList( int userID, Callback cb)
	{
		SendWithParams( "treasure/TreasureList", cb, new ITEMLIST(), 
		               "userID", userID); 
	}
	
	public void BuyShopItem( int userID, int itemID, Callback cb)
	{
		SendWithParams( "shop/BuyItem", cb, new MONEYPACKET(),
		               "userID", userID, "itemID", itemID );			
	}	
	
	public void Lobby( int userID, Callback cb)
	{
		SendWithParams( "game/Lobby", cb, new LOBBY(),
		               "userID", userID);			
	}
	
	public void BuyPurchaseItem(int userID, string productIdentify, string transactionIdentifier, string base64EncodedTransactionReceipt, string signature, Callback cb)
	{
		SendWithParams("shop/PayItem", cb, new BUYITEMPACKET(),
		               "userID", userID, "orderID", transactionIdentifier, "productID", productIdentify,
		               "purchaseToken", "", "receiptData", base64EncodedTransactionReceipt, "signature",""
		               );
	}
	
	public void PushID( int userID, string pushID, Callback cb)
	{
		SendWithParams( "user/PushID", cb, new Packet(), 
		               "userID", userID, "pushID", pushID ); 
	}
	
	public void Continue( int userID, int playCode, Callback cb)
	{
		SendWithParams( "game/ContinueGame", cb, new MONEYPACKET(),
		               "userID", userID, "playCode", playCode);			
	}
	
	public void Achievement( int userID, Dictionary<string, int> dicAchieve, Callback cb)
	{
		List<SENDACHIEVEMENT> list = new List<SENDACHIEVEMENT>();
		
		foreach(KeyValuePair<string, int> pair in dicAchieve)
			list.Add(new SENDACHIEVEMENT(pair.Key, pair.Value));
		
		SendWithParams( "game/AchievementProgress", cb, new ACHIEVEMENT(),
		               "userID", userID, "progress", BuildJson(list));			
	}
	
	public void AchievementReward( int userID, int achieveID, Callback cb)
	{
		SendWithParams( "game/Achievement", cb, new ACHIEVEMENT(),
		               "userID", userID, "achieveOriginalID", achieveID);			
	}
	
	public void UnlockAchievement( int userID, int achieveID, bool bCash, Callback cb)
	{
		SendWithParams( "game/UnlockAchievement", cb, new ACHIEVEMENT(),
		               "userID", userID, "achieveOriginalID", achieveID, "bCash", bCash);			
	}
	
	public void CheckVersion(Callback cb)
	{
		int os = 0; 
		#if UNITY_IPHONE
		os = 1;
		#elif UNITY_ANDROID
		os = 2;
		#endif
		
		SendWithParams("connect/init", cb, new CHECKVESION(), "os", os, "platform", IABManager.Instance.GetChannelName());			
	}
	
	public void GetGameServerUrl(string email,Callback cb)
	{
		SendWithParams("getbaseurl.php", cb, new BaseUrl(), "email", email, "platform", IABManager.Instance.GetChannelName());
	}
}

