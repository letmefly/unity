using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class StressTest : MonoBehaviour {


	class Player {

		//string id, password;

		int m_PlayerID;

		bool shouldLogin;

		void Login( string id, string password, bool joinIfNeed)
		{
			waiting = true;
			ServerManager.Network.Login( id, password, null, delegate ( CustomNetwork.Packet p) {
				//			DHUIManager.ShowWaitMessage(false);
				
				if( p.ERROR == 0) {
					CustomNetwork.LOGIN login = p as CustomNetwork.LOGIN;

					m_PlayerID = login.userID;

					Lobby();

					SkillList();
					GearList();
					StanceList();
					waiting = false;
                } 
				else if( p.ERROR == -101)
				{
					Join ( id, password, true);
				}
				else
					waiting = false;
                
                CommonPacketHandler(p);
            });		
		}

		bool waiting = false;

		public void Join( string id, string password, bool autoLogin)
		{
			m_PlayerID = 0;
			waiting = true;
			ServerManager.Network.Join( id, password, delegate ( CustomNetwork.Packet p) {
				//			DHUIManager.ShowWaitMessage(false);
				
				if( p.ERROR == 0 || p.ERROR == -103) {
					if( autoLogin)
						Login ( id, password, false);
					else
						waiting = false;
				}
				
				CommonPacketHandler(p);
			});		
		}

		public void JoinP( string id, string password, bool autoLogin)
		{
			m_PlayerID = 0;

			ServerManager.Network.JoinP( id, password, delegate ( CustomNetwork.Packet p) {
				//			DHUIManager.ShowWaitMessage(false);
				
				if( p.ERROR == 0 || p.ERROR == -103) {

					if( autoLogin)
						Login ( id, password, false);
				}
				
				CommonPacketHandler(p);
			});		
		}

		void Lobby()
		{
			ServerManager.Network.Lobby( m_PlayerID, delegate ( HttpNetwork.Packet p) 
			                            {
				CustomNetwork.LOBBY data = (CustomNetwork.LOBBY)p;
				if(p.ERROR == 0)
				{

                }
                
                CommonPacketHandler( p);
            }
            );		
		}

		CustomNetwork.FRIENDLIST friendList;
		void FriendList()
		{
			ServerManager.Network.FriendList( m_PlayerID, delegate ( HttpNetwork.Packet p){
				if(p.ERROR == 0)
				{
					friendList = (CustomNetwork.FRIENDLIST)p;
				}
                
                CommonPacketHandler(p);

                
            });	
		}

		void RankingList()
		{
			ServerManager.Network.RankingList( m_PlayerID, delegate ( HttpNetwork.Packet p){
				CommonPacketHandler(p);
            });	
		}


		int m_PlayCode;

		void StartAndEndGame( int iStageID, int iFriendID, bool endGame)
		{
			ServerManager.Network.GameStart( m_PlayerID, iStageID, new List<int>() ,
			                                iFriendID, delegate ( HttpNetwork.Packet p) {

				
				CustomNetwork.GAMESTART gameStart = (CustomNetwork.GAMESTART)p;
				if( p.ERROR == 0)
				{
					m_PlayCode = gameStart.playCode;

					if( endGame)
					{
						EndGame ();
					}

                }				
                
                CommonPacketHandler( p);
            });
		}

		void EndGame()
		{
			int iExp = Random.Range ( 0, 1000);
			int money = Random.Range ( 0, 1000);
			int score = Random.Range( 0, 1000);
			ServerManager.Network.GameResult( m_PlayerID, m_PlayCode, iExp, money, score, 10, Random.Range( 0, 2), Random.Range( 0, 2), 
			                                 PlayerInfo.Instance.SetEncryptionValue(Random.Range(1, 10)), GameManager.Instance.isVideoReborn, delegate ( HttpNetwork.Packet p)
	         {
		
				CustomNetwork.GAMERESULT gameresult = (CustomNetwork.GAMERESULT)p;
				if(p.ERROR == 0)
				{
					m_PlayCode = 0;
                }
                
                CommonPacketHandler(p);
            });	
            
		}

		CustomNetwork.MESSAGELIST messageList;
		void MessageList()
		{

			ServerManager.Network.MessageList( m_PlayerID, delegate ( HttpNetwork.Packet p){

				messageList = (CustomNetwork.MESSAGELIST)p;
				CommonPacketHandler(p);

				if( Random.Range(0, 2) == 0)
					MessageReceiveAll();
                
            });	
		}

		void MessageReceiveAll()
		{
			ServerManager.Network.MessageReceiveAll(m_PlayerID, delegate ( HttpNetwork.Packet p){
				
				CustomNetwork.MESSAGELISTRECEIVE result = (CustomNetwork.MESSAGELISTRECEIVE)p;
				CommonPacketHandler(p);
			});	
		}

		void Lottery()
		{
			ServerManager.Network.Lottery( m_PlayerID, delegate(HttpNetwork.Packet p) {

				CustomNetwork.LOTTERY lottery = (CustomNetwork.LOTTERY)p;
				if(p.ERROR == 0)
				{
				}
				CommonPacketHandler( p);
			});
		}

		void EquipSkill()
		{
			if( skillList != null && skillList.list.Length > 0)
			{
				int itemID = skillList.list[Random.Range( 0, skillList.list.Length)].i;
				int slotIndex = Random.Range( 0, 3);
				ServerManager.Network.EquipMystique( m_PlayerID, itemID, slotIndex, delegate(HttpNetwork.Packet p) {
					CustomNetwork.ITEMLIST data = (CustomNetwork.ITEMLIST)p;
					if(p.ERROR == 0)
					{
					}
					CommonPacketHandler( p);
				});
			}
		}

		void EquipGear()
		{
			if( gearList != null && gearList.list.Length > 0)
			{
				int itemID = gearList.list[Random.Range( 0, gearList.list.Length)].i;
				int slotIndex = Random.Range( 0, 3);
				ServerManager.Network.EquipArtifact( m_PlayerID, itemID, slotIndex, delegate(HttpNetwork.Packet p) {
					CustomNetwork.ITEMLIST data = (CustomNetwork.ITEMLIST)p;
					if(p.ERROR == 0)
					{
					}
					CommonPacketHandler( p);
				});
			}
		}

		public void Achievement()
		{
			//		UIManager.ShowWaitMessage(true); 

			string[] types = System.Enum.GetNames( typeof(AchieveManager.eType));

			Dictionary<string, int> dicAchieve = new Dictionary<string, int>();
			int count = Random.Range( 1, 10);
			for( int i = 0; i < count; i++)
			{
				dicAchieve.Add( types[Random.Range(0, types.Length)], Random.Range( 0, 100));
			}

			ServerManager.Network.Achievement( m_PlayerID, dicAchieve, delegate ( HttpNetwork.Packet p) {
				//			UIManager.ShowWaitMessage(false);
				
				CustomNetwork.ACHIEVEMENT data = (CustomNetwork.ACHIEVEMENT)p;

				CommonPacketHandler( p);
				
			});				
		}

		public void AchievementDuplication()
		{
			int count = Random.Range( 1, 10);

			for( int i = 0; i < count; i++)
				Achievement();
		}


		void SellGear()
		{
			if( gearList != null && gearList.list.Length > 0)
			{
				int itemID = gearList.list[Random.Range( 0, gearList.list.Length)].i;
				ServerManager.Network.SellArtifact( m_PlayerID, itemID, delegate(HttpNetwork.Packet p) {
					CustomNetwork.ITEMLIST data = (CustomNetwork.ITEMLIST)p;
					if(p.ERROR == 0)
					{
					}
					CommonPacketHandler( p);
				});
			}
		}

		public static Dictionary< int, int> m_gatchaResult = new Dictionary<int, int>();

		void BuyArtifact()
		{

			ServerManager.Network.BuyArtifact( m_PlayerID, Random.Range( 1, 3), 0, "1", delegate(HttpNetwork.Packet p) {
				CustomNetwork.GATCHA data = (CustomNetwork.GATCHA)p;

				if(p.ERROR == 0)
				{
				}
				CommonPacketHandler( p);
			});
		}
		void BuyArtifactForStatistic( int type)
		{
			
			ServerManager.Network.BuyArtifact( m_PlayerID, type, 0, "1", delegate(HttpNetwork.Packet p) {
				if(p.ERROR == 0)
				{
					CustomNetwork.GATCHA data = (CustomNetwork.GATCHA)p;
					int itemID = data.itemOriginalID;
					if( m_gatchaResult.ContainsKey( itemID) == false)
						m_gatchaResult[itemID] = 0;
					
					m_gatchaResult[itemID] ++;
				}
				CommonPacketHandler( p);
			});
		}


		CustomNetwork.ITEMLIST stanceList, gearList, skillList;
		public void StanceList()
		{
			ServerManager.Network.CharacterList( m_PlayerID, delegate(HttpNetwork.Packet p)
			                                    {
				stanceList = (CustomNetwork.ITEMLIST)p;
				if(p.ERROR == 0)
				{
				}
				CommonPacketHandler( p);
			});
		}
		
		public void SkillList()
		{
			ServerManager.Network.SkillList( m_PlayerID, delegate(HttpNetwork.Packet p)
			                                {
				skillList = (CustomNetwork.ITEMLIST)p;
				if(p.ERROR == 0)
				{
				}
				CommonPacketHandler( p);
			});
		}
		
		public void GearList()
		{
			ServerManager.Network.TreasureList( m_PlayerID, delegate(HttpNetwork.Packet p)
			                                   {
				CustomNetwork.ITEMLIST data = (CustomNetwork.ITEMLIST)p;
				if(p.ERROR == 0)
				{
					gearList = (CustomNetwork.ITEMLIST)p;
				}
				CommonPacketHandler( p);
			});
		}


		int friednRequestCount;
		public void FriendSuggest(bool add)
		{
			ServerManager.Network.FriendSuggest( m_PlayerID, delegate ( HttpNetwork.Packet p){
				if(p.ERROR == 0)
				{
					CustomNetwork.FRIENDFINDLIST data = (CustomNetwork.FRIENDFINDLIST)p;
					if( add && data.users.Length> 0 //&& friednRequestCount < 5
					   )
						FriendRequest( data.users[Random.Range(0, data.users.Length)].userID);
				}
				
				CommonPacketHandler(p);
				
			});	
		}
		
		public void FriendFind(string keyword)
		{
			ServerManager.Network.FriendFind( m_PlayerID, keyword, delegate ( HttpNetwork.Packet p){
				if(p.ERROR == 0)
				{
					CustomNetwork.FRIENDFINDLIST data = (CustomNetwork.FRIENDFINDLIST)p;
				}
				
				CommonPacketHandler(p);

				
			});	
		}
		
		public void FriendDelete(int friendID)
		{
			ServerManager.Network.FriendDelete( m_PlayerID, friendID, delegate ( HttpNetwork.Packet p){
				CommonPacketHandler(p);

				
			});	
		}
		
		public void FriendGift(int friendID)
		{
			ServerManager.Network.FriendGift( m_PlayerID, friendID, delegate ( HttpNetwork.Packet p){
				CommonPacketHandler(p);

            });	
        }
        
        public void FriendRequestAdmit(int friendID)
        {
            ServerManager.Network.FriendRequestAdmit( m_PlayerID, friendID, delegate ( HttpNetwork.Packet p){
                CommonPacketHandler(p);
            });	

        }
        
        public void FriendRequest(int friendID)
        {

			friednRequestCount++;
            ServerManager.Network.FriendRequest( m_PlayerID, friendID, delegate ( HttpNetwork.Packet p){
                CommonPacketHandler(p);
            });	
        }


		void FriendManage()
		{
			if( friendList == null)
				FriendList();
			else
			{
				int maxFriend = 20;

				int friendCount = friendList.friends.Length;

//				switch( 0)
				switch( Random.Range( 0, 4))
				{
				case 0:
	//				if( maxFriend > friendCount)
	//					FriendSuggest( true);
					break;

				case 1:
					if( friendCount> 0)
						FriendDelete( friendList.friends[Random.Range ( 0, friendCount)].userID);
					break;

				case 2:
				{
					if( friendList.waitings.Length > 0)
					{
						int requestor = friendList.waitings[ Random.Range( 0, friendList.waitings.Length)].userID;
						FriendRequestAdmit( requestor);
					}
				}
					                                             break;
				case 3:
					if( friendCount > 0)
						FriendGift( friendList.friends[Random.Range ( 0, friendCount)].userID);
					break;
				}
	
			}
		}

		long m_Money, m_Cash;
		int m_Stamina;

		System.DateTime m_StaminaGenTime;
		int m_Exp, m_Level, m_lotteryHighCoupon, m_lotteryCoupon, m_lotteryPoint;

		
		void CommonPacketHandler( CustomNetwork.Packet p)
		{
			if( p.ERROR == 0)
			{
				System.Reflection.FieldInfo info;
				
				info = p.GetType().GetField( "money");
				if( info != null)
				{
					m_Money = (long)info.GetValue( p);
				}
				
				info = p.GetType().GetField( "cash");
				if( info != null)
				{
					m_Cash = (long)info.GetValue( p);
				}			
				
				info = p.GetType().GetField( "heart");
				if( info != null)
				{
					m_Stamina = (int)info.GetValue( p);
				}
				
				info = p.GetType().GetField( "heartTimeSeconds");
				if( info != null)
				{
					int iHeartSecond = (int)info.GetValue( p);
//					if( iHeartSecond != 0)
//						m_StaminaGenTime = System.DateTime.Now.AddSeconds( -Config.Instance.staminaPerSec + iHeartSecond);
				}
				
				info = p.GetType().GetField( "exp");
				if( info != null)
				{
					m_Exp = (int)info.GetValue( p);
				}			
				
				info = p.GetType().GetField( "level");
				if( info != null)
				{
					m_Level = (int)info.GetValue( p);
				}
				
				info = p.GetType().GetField( "lotteryPoint");
				if( info != null)
				{
                    m_lotteryPoint = (int)info.GetValue( p);
                }
                
                info = p.GetType().GetField( "lotteryHighCoupon");
                if( info != null)
                {
                    m_lotteryHighCoupon = (int)info.GetValue( p);
                }
                
                info = p.GetType().GetField( "lotteryCoupon");
                if( info != null)
                {
                    m_lotteryCoupon = (int)info.GetValue( p);
                }
            }
            else
                Util.DebugLog( p.DECODED_ERROR_MESSAGE);
            
        }

		void LoginRandom( bool joinIfNeed)
		{
			id = randomTestAccount;
			Login ( id, "12345", joinIfNeed);
		}


		string randomTestAccount {
			get {
//				return string.Format( "dummy-{0}@tangent", Random.Range (1, 1000));
				return string.Format( "tangent{0}", Random.Range (1, 1000));
			}
		}

		string id;
		void JoinRandom( bool autoLogin)
		{
//			id = "tangentJoin"+Random.Range (100000, 10000000)+System.DateTime.Now.Ticks;
//			id = "GatchaTest"+Random.Range (1, 10);
			id = randomTestAccount;
			if( StressTest.useJoinP)
			{
				JoinP ( id, "12345", autoLogin);
			}
			else
			{
				Join ( id, "12345", autoLogin);
			}
		}

		bool IsJoining {
			get {
				return string.IsNullOrEmpty( id) == false;
			}
		}


		public void Update()
		{
			if( StressTest.testMode == TestMode.JoinTest)
			{

				JoinRandom( false);
			} 
			else if( StressTest.testMode == TestMode.GatchaTest)
			{
				bool shouldLogin = m_PlayerID == 0;
				
				if( shouldLogin && IsJoining == false)
				{
					JoinRandom( true);

				}
				else if( shouldLogin == false)
				{
					//  advanced ? 2 : 1, 0
					BuyArtifactForStatistic( 10);
				}
			}
			else if( 	waiting == false)
			{
				bool shouldLogin = m_PlayerID == 0;

				if( shouldLogin)
				{
					string id = randomTestAccount;
					Login ( id, "12345", true);
				}
				else
				{
						int action = Random.Range( 0, 20);

						switch ( action) {
							//				switch ( 4) {
						case 0:
							FriendList();
							break;
						case 1:
							RankingList();
							break;
						case 3:
							MessageList();
							break;
							
						case 4:
							FriendManage();
							break;
							
						case 5:
							LoginRandom( false);
							break;
							
						case 6:
							Lottery();
							break;
						case 7:
							EquipSkill();
							break;
						case 8:
							EquipGear();
							break;
							
						case 9:
							BuyArtifact();
							break;
						case 10:
							SellGear();
							break;
						case 11:
							JoinRandom( true);
							break;
					case 12:
						AchievementDuplication();
						break;
								
						default:
						{
							int friendId = friendList != null && friendList.friends.Length > 0 ? friendList.friends[Random.Range( 0, friendList.friends.Length)].userID : 0;
							int stageId = Random.Range( 0, 140);
							StartAndEndGame( Random.Range ( 0, 2) == 0 ? 0 : stageId, friendId, Random.Range( 0, 2) == 0 ? true : false);
						}
							break;
					}
				}
			}
		}
    }




	public int clientCount = 100;

	public float requestsPerSec = 1.0f;

	List<Player> m_players = new List<Player>();


	float updateTimer;

	bool playing = false;

	public enum TestMode {
		JoinTest,
		GatchaTest,
		NormalTest
	}


	public static TestMode testMode;

	public static bool useJoinP = false;

	void Start()
	{
		if( ServerManager.Instance.m_DevServer == false)
		{
#if UNITY_EDITOR
			Debug.LogError( "!!!!! Test Server !!!!!");

#endif
			Application.Quit();
		}

		Application.runInBackground = true;
	}

	void Update()
	{
		if( clientCount > m_players.Count)
		{
			int currentCount = m_players.Count;
//			for( int i = currentCount; i < clientCount; i++)
				m_players.Add ( new Player());
		}

		else if( clientCount < m_players.Count)
		{
			Player player = m_players[Random.Range(0, m_players.Count)];

			m_players.Remove( player);

		}

		updateTimer += Time.deltaTime;

		int maxWWWs = 100;
		if( updateTimer > 1/requestsPerSec && playing && ServerManager.Network.m_packetCount < maxWWWs)
		{
			updateTimer = 0;
			m_players.ForEach( p => p.Update());
		}

		float checkDuration = 1.0f;

		if( sendedPerSecTimer > checkDuration)
		{
			float sended = HttpNetwork.Packet.sended-prevSended;
			sendedPerSec = sended/sendedPerSecTimer;

			sendedPerSecTimer = 0;
			prevSended = HttpNetwork.Packet.sended;
		}
		else
			sendedPerSecTimer += Time.deltaTime;



		if( receivedPerSecTimer > checkDuration)
		{
			
			float received = HttpNetwork.Packet.received-prevReceived;
			receivedPerSec = received/receivedPerSecTimer;
			
			receivedPerSecTimer = 0;
			prevReceived = HttpNetwork.Packet.received;
        }
        else
			receivedPerSecTimer += Time.deltaTime;
	}

	float sendedPerSec, sendedPerSecTimer, prevSended;
	float receivedPerSec, receivedPerSecTimer, prevReceived;

	void OnGUI()
	{
		GUILayoutOption height = GUILayout.Height( 50);

		bool prevPlaying  = playing;
		playing = GUILayout.Toggle( playing, "Play", height);

		if( prevPlaying == true && playing == false)
		{
			string keys = string.Empty, values = string.Empty;
			foreach( KeyValuePair<int, int> item in Player.m_gatchaResult)
			{
				keys += string.Format( "{0}\n", item.Key, item.Value);
				values += string.Format( "{1}\n", item.Key, item.Value);
			}
			Debug.Log ( keys);
			Debug.Log ( values);
		}

		if( prevPlaying == false && playing == true)
			Player.m_gatchaResult.Clear();

		//joinOnly = GUILayout.Toggle( joinOnly, "JoinOnly", height);


		string[] testModes = System.Enum.GetNames( typeof(TestMode));
		testMode = (TestMode)GUILayout.SelectionGrid( (int)testMode, testModes, testModes.Length);

		useJoinP = GUILayout.Toggle( useJoinP, "UseJoinProcedure", height);


		GUILayout.Label( string.Format( "Clients:{0}/{1}", m_players.Count, clientCount));
		string c = GUILayout.TextField( clientCount.ToString(), height);
		int.TryParse( c, out clientCount);

		GUILayout.Label( string.Format( "Sended:{0}, PerSec:{1}", HttpNetwork.Packet.sended, sendedPerSec));
		GUILayout.Label( string.Format( "Received:{0}, PerSec:{1}", HttpNetwork.Packet.received, receivedPerSec));




		string r = GUILayout.TextField( requestsPerSec.ToString(), height);
		float.TryParse( r, out requestsPerSec);



	}

}

