using System;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;


public static class ZipCompress
{
	
	public static byte[] Compress(string d)
	{
		using(var m = new MemoryStream())
		{
			byte[] data = System.Text.Encoding.Default.GetBytes( d);
			var br = new BinaryWriter(m);
			var z = new DeflaterOutputStream(m);
			br.Write(data.Length);
			z.Write(data, 0, data.Length);
			z.Flush();
			z.Close();
			return m.GetBuffer();
		}
	}
	
	public static string Decompress(string data)
	{
		byte[] output = null;

		var m = new MemoryStream(Convert.FromBase64String(data));
		var z = new InflaterInputStream(m);
		var br = new BinaryReader(m);
		var length = br.ReadInt32();
	    output = new byte[length];
		z.Read(output, 0, length);
		z.Close();
		m.Close();
		return System.Text.Encoding.Default.GetString( output);
	}
}
